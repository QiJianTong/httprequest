/**
 * 
 */
package runnable;

import service.HttpRequestService;

/**
 * @author Administrator
 *
 */
public class ProgramEntry {

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		
			  HttpRequestService httpRequestService = new HttpRequestService();
			  httpRequestService.run();
		

	}

}
