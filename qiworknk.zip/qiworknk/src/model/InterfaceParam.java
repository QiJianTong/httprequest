package model;

import java.util.LinkedHashMap;
import java.util.Map;

import constants.Constants;

/**
 * @author Administrator
 * @category 请求接口目标参数
 */
public class InterfaceParam {

	private String token = "请求接口token串";
	private String method = "请求接口方法名";
	private String format = "json";
	
	public InterfaceParam(String token) {
		super();
		this.token = token;
	}

	public InterfaceParam(String token, String method, String format) {
		super();
		this.token = token;
		this.method = method;
		this.format = format;
	}

	public String getToken() {
		return token;
	}

	public String getMethod() {
		return method;
	}

	public String getFormat() {
		return format;
	}

	public void setToken(String token) {
		this.token = token;
	}

	public void setMethod(String method) {
		this.method = method;
	}

	public void setFormat(String format) {
		this.format = format;
	}
	
	
	
	
}
