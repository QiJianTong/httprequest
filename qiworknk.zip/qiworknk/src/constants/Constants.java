/**
 * 
 */
package constants;

/**
 * @author Administrator
 *
 */
public class Constants {
	/**接口参数
	 * 
	 */
	public static final String TOKEN  ="token";
	public static final String METHOD = "method";
	public static final String FORMAT = "format";
	
	/**服务端响应码
	 * 
	 */

	
	
	
}
