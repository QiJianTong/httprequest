/**
 * 
 */
package test;

import java.util.HashMap;
import java.util.Map;

 
import junit.framework.TestCase;
import model.InterfaceParam;
import model.Param;
import service.HttpRequestService;
import util.HttpRequestUtil;
import util.JSONUtil;
import util.URLUtil;
 
/**
 * @author Administrator
 *
 */
 
public class Test extends TestCase{

	
	public void test(){
		  HttpRequestService httpRequestService = new HttpRequestService();
		  httpRequestService.run();
	}
}
