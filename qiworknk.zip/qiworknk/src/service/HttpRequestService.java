/**
 * 
 */
package service;

import model.InterfaceParam;
import model.Param;
import util.HttpRequestUtil;
import util.JSONUtil;
import util.URLUtil;

/**
 * @author Administrator
 *
 */
public class HttpRequestService implements Runnable{
 
	/* (non-Javadoc)
	 * @see java.lang.Runnable#run()
	 */
	@Override
	public void run() {
		//接口调用地址
		String requestURL = URLUtil.setURL("https://api.apiopen.top/getWangYiNews", 
				URLUtil.setParam(new InterfaceParam("请求接口token串", "请求接口方法名", "json")));
		
		//接口json数据块
		String data = JSONUtil.Data(new Param(" "," "," "));
		
		//发送http请求调用接口
		HttpRequestUtil.doPost(requestURL, "POST", data);
		
		//token失效返回401验证身份
		
		//请求token
		
		
		//
		System.out.println(
				URLUtil.setURL("https://api.apiopen.top/getWangYiNews", 
						URLUtil.setParam(new InterfaceParam("请求接口token串", "请求接口方法名", "json"))));
	}
}
