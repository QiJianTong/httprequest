/**
 * 
 */
package util;

import java.util.HashMap;
import java.util.Map;

import com.alibaba.fastjson.JSON;
import com.alibaba.fastjson.JSONObject;

import model.Param;

/**
 * @author Administrator
 *
 */
public class JSONUtil {

	public static String Data(Param param){
		 
		 
		String json = JSON.toJSONString(param);
		
		return json;
		
	}
}
