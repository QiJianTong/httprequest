/**
 * 
 */
package util;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.PrintWriter;
import java.net.HttpURLConnection;
import java.net.MalformedURLException;
import java.net.URL;

 

/**
 * @author Administrator
 *
 */
public class HttpRequestUtil {
 
	public static String doPost(String requestURL, String method, String data) {
		 
		PrintWriter out = null;
		InputStream is = null;
		StringBuffer sb = null;
		BufferedReader br = null;
		HttpURLConnection conn = null;
		String str = "";
		try { 
			//创建连接
			URL url = new URL(requestURL);
			conn = (HttpURLConnection) url.openConnection();
			
			
	        conn.setRequestMethod(method);//设置提交类型 
	        conn.setDoOutput(true);//设置允许写出数据,默认是不允许 false 
	        conn.setDoInput(true);//当前的连接可以从服务器读取内容, 默认是true 
	        
	        
            out = new PrintWriter(conn.getOutputStream());//获取URLConnection对象对应的输出流
            out.print(data);//发送请求参数即数据
            out.flush();//缓冲数据
            
            if (HttpURLConnection.HTTP_OK == conn.getResponseCode()) {
            	  is = conn.getInputStream();//获取URLConnection对象对应的输入流
            	  br = new BufferedReader(new InputStreamReader(is));//构造一个字符流缓存
                  while ((str = br.readLine()) != null) {
                      System.out.println(str);
                      sb.append(str);
                  }
                  
                  System.out.println("完整结束");
            	} else {
            	  
            	   System.out.println("服务器连接异常"+conn.getResponseCode());
            	   return "400";
            	}
              
			
		} catch (Exception e) { 
			
			e.printStackTrace();
		}  
        finally {
            try {
            	//关闭流
                if (out != null) {
                    out.close();
                }
                if (is != null) {
                    is.close();
                }
                if (br != null) {
                    br.close();
                }
                if (conn != null) {
                	conn.disconnect();
                }
            } catch (IOException ex) {
                ex.printStackTrace();
            }
        }
		return sb.toString();
	}
	

}
