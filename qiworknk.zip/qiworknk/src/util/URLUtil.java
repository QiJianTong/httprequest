/**
 * 
 */
package util;

import java.util.Iterator;
import java.util.LinkedHashMap;
import java.util.Map;
import java.util.Map.Entry;

import constants.Constants;
import model.InterfaceParam;

/**
 * @author Administrator
 *
 */
public class URLUtil {
	

	/**存参方法
	 * 
	 * @param TOKEN  	接口参数
	 * @param METHOD 	接口方法名
	 * @param FORMAT	接口数据类型
	 * @param ip 		接口参数对象
	 * @return			map对象
	 */
	public static Map<String ,String>  setParam(InterfaceParam ip){
		Map<String,String> map = new LinkedHashMap<>();
		map.put(Constants.TOKEN, ip.getToken());
		map.put(Constants.METHOD, ip.getMethod());
		map.put(Constants.FORMAT, ip.getFormat());
		return map;
		
	}
	/**url拼接方法
	 * 
	 * @param path 请求路径
	 * @param param 请求参数map集合
	 * @return url 完整接口调用路径
	 * 
	 */
	public static String setURL(String url,Map<String, String> param){
		
		url +="?";
		Iterator<Entry<String, String>> iterator = param.entrySet().iterator();
		while(iterator.hasNext()){
			Entry<String, String> parammap = iterator.next();
			String mapKey = "";
			String mapValue = "";
			
			//判断是否最后一个，结束拼接&字符
			if(iterator.hasNext()){
				mapKey = parammap.getKey();
				mapValue = parammap.getValue();
				url += mapKey+"="+mapValue+"&";
			}else{
				mapKey = parammap.getKey();
				mapValue = parammap.getValue();
				url += mapKey+"="+mapValue;
			}
		}
		
		return url;//返回拼接完成的接口地址
		
	}
	
}
